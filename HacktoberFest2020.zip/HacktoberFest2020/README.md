<p align="center">
    <a href="https://hacktoberfest.digitalocean.com/" target="_blank">
    	<img src="https://hacktoberfest.digitalocean.com/assets/HF-full-logo-b05d5eb32b3f3ecc9b2240526104cf4da3187b8b61963dd9042fdc2536e4a76c.svg" >
    </a>
</p>
<center>:sparkles:<h4>1 OCTOBER - 31 OCTOBER</h4>:sparkles:<center>
Pull request and add any feature to the website.:octocat:
    
* [Click here to visit the website.](https://rakshit234.github.io/HacktoberFest2020/)
* [Click here to register for hacktoberfest2020.](https://hacktoberfest.digitalocean.com/)

Add Your Contribution's to this repository by doing following operations:
- I have added the image of t-shirt in the repo, you can add it anywhere it looks good.
- Also you can make this webpage mobile browser compatible and tablet compatible.
- Add image in title bar of hacktoberfest logo.
- Add Transition through CSS to make it look great.
- Add Animation for smooth experience.
- Add Hover Effects on buttons and links in the website.
- Change text color inside the button.
- Can add links to hacktoberfest social media accounts like instagram, twitter, etc.
- Can also link to digital ocean official website.
- Can improve the text "Steps to be followed".
- Can also focus on motivating others to plant a tree this hacktoberfest'20.

Special thanks:+1: to:

* [bluecypher](https://github.com/bluecypher)
* [Skiller847](https://github.com/Skiller847)
* [vd152](https://github.com/vd152)
* [preity-p](https://github.com/preity-p)
* [Manitej66](https://github.com/Manitej66)
* [RoyalEagle73](https://github.com/RoyalEagle73)
* [mdzaidalam52](https://github.com/mdzaidalam52)
* [mukesh2309](https://github.com/mukesh2309)
* [hudiansyahrobby](https://github.com/hudiansyahrobby)

<br />
<a href="https://ctt.ac/Vu1a7"><img src="https://www.flaticon.com/svg/static/icons/svg/733/733635.svg" width="50px" height="50px" style="padding:30px"/></a> 
<a href="https://www.facebook.com/sharer/sharer.php?u=https://hacktoberfest.digitalocean.com/"><img src="https://www.flaticon.com/svg/static/icons/svg/1384/1384005.svg" width="50px" height="50px" style="padding:30px"/></a> 
<a href="https://www.linkedin.com/sharing/share-offsite/?url=https://hacktoberfest.digitalocean.com/"><img src="https://www.flaticon.com/svg/static/icons/svg/1384/1384014.svg" width="50px" height="50px"/></a> 
